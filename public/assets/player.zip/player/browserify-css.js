'use strict';
module.exports = {
    autoInject: true,
    minify: true,
    rootDir: '.',
};
